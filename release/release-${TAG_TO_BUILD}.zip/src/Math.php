<?php

namespace TestPhpProject;

Class Math
{
    public function __construct()
    {
        $this->_test = '1';
    }

    public function add($x, $y)
    {
        return $x+$y;
    }
}